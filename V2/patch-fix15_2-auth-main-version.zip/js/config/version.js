export const APP_VERSION = "V2-fix15.2";
