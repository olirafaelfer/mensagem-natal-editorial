// js/modules/ranking.js — Ranking V2 (V7.5)
// Refatorado: evitar crashes por modal/app indefinidos e remover sintaxes inválidas.
//
// Requisitos mínimos:
// - app.db (Firestore instance)
// - app.fs com collection/getDocs/query/orderBy/limit
// - app.modal.open(title, html) (ui-modal.js)

export function bootRanking(app){
  // Compat: alguns builds antigos chamavam window.toggleRanking
  window.toggleRanking = () => openRanking();

  const btn = document.getElementById("rankingBtn");
  if (btn && !btn.__rankingBound){
    btn.__rankingBound = true;
    btn.addEventListener("click", () => openRanking());
  }

  async function openRanking(){
    const modalOpen = app?.modal?.open || window.openModal;
    if (!modalOpen){
      console.warn("[ranking] modal não disponível");
      alert("Ranking indisponível (modal não carregado).");
      return;
    }

    // placeholder
    modalOpen("Ranking", `<p style="margin:0">Carregando ranking…</p>`);

    try{
      if (!app?.db || !app?.fs){
        modalOpen("Ranking", `<p style="margin:0">Ranking indisponível (Firestore não inicializado).</p>`);
        return;
      }

      const { collection, getDocs, query, orderBy, limit } = app.fs;

      const q = query(
        collection(app.db, "rankingByEmail"),
        orderBy("overallAvg", "desc"),
        limit(50)
      );

      const snap = await getDocs(q);

      const rows = [];
      snap.forEach(docSnap => {
        const d = docSnap.data() || {};
        if (d.visible === false) return; // query pode não filtrar
        rows.push({
          name: d.name || "—",
          sector: d.sector || "—",
          overallAvg: typeof d.overallAvg === "number" ? d.overallAvg : 0,
          avatar: d.avatar || d.photoURL || "", // compat
        });
      });

      const html = render(rows);
      modalOpen("Ranking", html);
    }catch(err){
      console.error("[ranking] falha ao carregar:", err);
      modalOpen("Ranking", `<p style="margin:0">Falha ao carregar ranking.</p><pre style="white-space:pre-wrap;margin-top:8px;opacity:.85">${escapeHtml(String(err?.message||err))}</pre>`);
    }
  }

  function render(rows){
    if (!rows.length){
      return `<p style="margin:0">Ainda não há jogadores visíveis no ranking.</p>`;
    }

    const trs = rows.map((r, idx) => {
      const medal = idx===0 ? "🥇" : idx===1 ? "🥈" : idx===2 ? "🥉" : "";
      const avatar = r.avatar
        ? `<img src="${escapeAttr(r.avatar)}" alt="" style="width:28px;height:28px;border-radius:999px;object-fit:cover;border:1px solid rgba(255,255,255,.15)">`
        : `<div style="width:28px;height:28px;border-radius:999px;background:rgba(255,255,255,.12);display:flex;align-items:center;justify-content:center;font-weight:700">${escapeHtml((r.name||" ").trim().slice(0,1).toUpperCase())}</div>`;
      return `
        <tr>
          <td style="padding:8px 6px;white-space:nowrap">${medal} ${idx+1}</td>
          <td style="padding:8px 6px">${avatar}</td>
          <td style="padding:8px 6px">${escapeHtml(r.name)}</td>
          <td style="padding:8px 6px;opacity:.85">${escapeHtml(r.sector)}</td>
          <td style="padding:8px 6px;text-align:right;font-weight:700">${formatScore(r.overallAvg)}</td>
        </tr>
      `;
    }).join("");

    return `
      <div style="overflow:auto;max-height:70vh">
        <table style="width:100%;border-collapse:collapse;font-size:14px">
          <thead>
            <tr style="text-align:left;opacity:.9">
              <th style="padding:8px 6px">#</th>
              <th style="padding:8px 6px">Foto</th>
              <th style="padding:8px 6px">Nome</th>
              <th style="padding:8px 6px">Setor</th>
              <th style="padding:8px 6px;text-align:right">Geral</th>
            </tr>
          </thead>
          <tbody>${trs}</tbody>
        </table>
      </div>
    `;
  }

  function formatScore(x){
    if (typeof x !== "number" || !isFinite(x)) return "0";
    // mantém sem casas quando inteiro
    return Number.isInteger(x) ? String(x) : x.toFixed(2);
  }

  function escapeHtml(s){
    return String(s ?? "").replace(/[&<>"']/g, (c) => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
  }

  function escapeAttr(s){
    // básico (evita quebrar o atributo)
    return escapeHtml(s).replace(/`/g, "");
  }

  return { open: openRanking };
}
