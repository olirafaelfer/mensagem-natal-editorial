// shim (V7.5)
export { bootAuth } from "./modules/auth.js";
