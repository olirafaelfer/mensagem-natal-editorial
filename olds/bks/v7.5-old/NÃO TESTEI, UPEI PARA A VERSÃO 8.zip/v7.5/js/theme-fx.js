// shim (V7.5)
export { bootThemeFx } from "./modules/theme-fx.js";
