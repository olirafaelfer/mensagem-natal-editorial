export const APP_VERSION = "V7.5";
export const BUILD_ID = "v7.5";
