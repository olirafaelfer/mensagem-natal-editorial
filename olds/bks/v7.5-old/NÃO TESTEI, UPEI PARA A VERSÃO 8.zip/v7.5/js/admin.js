// shim (V7.5)
export { bootAdmin } from "./modules/admin.js";
